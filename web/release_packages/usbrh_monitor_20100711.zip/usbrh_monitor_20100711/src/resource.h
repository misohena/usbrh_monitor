//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by usbrh_monitor.rc
//
#define IDD_MAIN                        101
#define IDC_STATIC_STATUS               1001
#define IDC_EDIT_OUTPUT_FILE            1003
#define IDC_EDIT2                       1004
#define IDC_EDIT_OUTPUT_URL             1004
#define ID_POPUP_ABOUT                  40001
#define ID_POPUP_EXIT                   40002
#define IDM_EXIT                        40003
#define IDM_ABOUT                       40004
#define ID_POPUP_MONITORSETTINGS        40005
#define IDM_MONITOR                     40006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40007
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
